import { useState,useEffect } from "react";
import MaterialTable from "@material-table/core";
import swal from 'sweetalert';


const Items = () => {
 
  const submitHandler = (e) => {
    e.preventDefault();
    console.log(data);
    fetch("http://localhost:8080/saveItem", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
        },
        body: JSON.stringify(data),
    })
    .then(() => {
        console.log("department Added");
        swal("Success", "Item Saved Successfully", "success").then(() => {
            window.location.reload(true);
        });
    })
    .catch((err) => console.log(err));
};

  const [data, setData] = useState([]);
  const inputChangeHandler = (e) => {
    let newData = { ...data };
    newData[e.target.name] = e.target.value;
    setData(newData);
  };

  const [ticketDetails, setTicketDetails] = useState([]);
  const options = { method: "GET" };
  const fetchData=()=>{
    fetch("http://localhost:8080/getItem", options)
    .then((response) => response.json())
    .then((response) => setTicketDetails(response))
    .catch((err) => console.error(err));
  }
  
  useEffect(()=>{
    fetchData();
  },[])
  
  return (
    <>
      <div className="container">
        <div className="d-flex">
          <h3>Add Items</h3>
        </div>
        <hr />
        <h6>Add Item Name</h6>
        <form onSubmit={submitHandler} className="bg-light">
          <div className="row ">
            <div className="col-sm-6 mt-2">
              <label for="cars" id="label">
                Item Name:
              </label>
              <br />
              <input
                value={data.name}
                type="text"
                class="form-control"
                id="formGroupExampleInput"
                name="name"
                onChange={inputChangeHandler}
                placeholder="Enter Item Name"
              />
            </div>

            <div className="col-sm-6 mt-2">
              <label for="cars" id="label">
                Description:
              </label>
              <br />
              <input
                value={data.description}
                type="text"
                class="form-control"
                id="formGroupExampleInput"
                name="description"
                onChange={inputChangeHandler}
                placeholder="Enter Description Here"
              />
            </div>
          </div>
          <button type="submit" class="btn btn-primary mt-4" >
            Save
          </button>

        </form>
        <br/>
        <MaterialTable
        title="Item Record"
        data={ticketDetails}
       
          columns={[
            {
              title: "Item Name",
              field: "name",
            },

            {
              title: "Description",
              field: "description",
            },
          ]}
        />
      </div>
    </>
  );
};

export default Items;
