package com.item.item.service;

import com.item.item.entity.Items;
import com.item.item.repository.ItemRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class ItemsService {
    @Autowired
    ItemRepo itemRepo;

    @PostMapping("/saveItem")
    public ResponseEntity<Items> addItem(@RequestBody Items item) {
       itemRepo.save(item);
        return ResponseEntity.ok(item);
    }

    @GetMapping("/getItem")
    public List<Items>getItems() {
     return itemRepo.findAll();
    }

    @GetMapping("/{name}")
    public Items searchItems(@PathVariable String name) {

        return itemRepo.findByName(name);
    }
}

