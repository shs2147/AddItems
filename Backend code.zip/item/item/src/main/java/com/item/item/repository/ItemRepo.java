package com.item.item.repository;

import com.item.item.entity.Items;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ItemRepo extends JpaRepository<Items,Integer> {
    Items findByName(String name);
}

